# Raw Content Provenance Note

**Source ID:** `REPORT-DOSHI-VELEZ-KIM-2017`
**Acquisition Mode:** `web-retrieved`
**Retrieved / Received:** `2026-04-28`
**Pin / Version:** `arxiv:1702.08608v2`
**Origin URL / Supplier:** `https://arxiv.org/abs/1702.08608`

## Raw Files

| File        | Kind           | Notes                                                  |
| ----------- | -------------- | ------------------------------------------------------ |
| `README.md` | `html-excerpt` | abstract captured from arXiv metadata and page content |

## Provenance Notes

- Retrieved from the public arXiv abstract page.
- This is an excerpt-level raw artifact, not a preserved full PDF.

## Captured Excerpt

As machine learning systems become ubiquitous, there has been a surge of interest in interpretable machine learning: systems that provide explanation for their outputs. These explanations are often used to qualitatively assess other criteria such as safety or non-discrimination. However, despite the interest in interpretability, there is very little consensus on what interpretable machine learning is and how it should be measured. In this position paper, we first define interpretability and describe when interpretability is needed (and when it is not). Next, we suggest a taxonomy for rigorous evaluation and expose open questions towards a more rigorous science of interpretable machine learning.
